package com.example.tintint_jw.TeamInfo

class TeamInfoData(val mainImage:Int, val position: String, val name: String ) {


}