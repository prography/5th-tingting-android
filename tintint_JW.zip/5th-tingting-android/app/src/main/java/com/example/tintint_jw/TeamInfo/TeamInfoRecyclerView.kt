package com.example.tintint_jw.TeamInfo

class TeamInfoRecyclerView {
}