package com.example.tintint_jw.Retrofit.Login

import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

interface LoginRetrofitItf {
  /*  @Header("인증키")
    @GET("주소")
    fun requestLogin(
        @Query("query") keyword : String,
        @Query("sort") sort : String ="receny",
        @Query("page")

        )
*/

}