package com.example.tintint_jw.View

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tintint_jw.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
